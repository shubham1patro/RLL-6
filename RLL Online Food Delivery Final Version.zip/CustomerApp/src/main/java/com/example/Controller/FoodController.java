//package com.example.Controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.context.annotation.Scope;
//import org.springframework.http.MediaType;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.Service.FoodService;
//import com.example.pojo.Food;
//
//@RestController
//@Scope(value="request")
//public class FoodController {
//
//	@Autowired
//	@Qualifier("foodService")
//	private FoodService foodService;
//	
//	@GetMapping(value="/foods",produces= {MediaType.APPLICATION_JSON_VALUE})
//	public List<Food> getAllFoods() {
//		return foodService.getAllFoods();
//	}
//	
//	@GetMapping(value="/food/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
//	public Food getFoodById(@PathVariable("id") Integer id) {
//		return foodService.getFoodById(id);
//	}
//}
