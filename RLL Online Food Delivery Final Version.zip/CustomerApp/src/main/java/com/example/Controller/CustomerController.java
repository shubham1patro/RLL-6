package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.CustomerService;
import com.example.pojo.Address;
import com.example.pojo.Customer;

@RestController
@Scope(value="request")
public class CustomerController {

	@Autowired
	@Qualifier(value="customerService")
	CustomerService customerService;

	@PostMapping(value="/register",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED)
	public String registerCustomer(@RequestBody Customer customer) {
		Customer c1 = customerService.getCustomerByEmail(customer.getCustomerEmail());
		if (c1 != null)
			return "Email already exists!";
		Customer c2 = customerService.getCustomerByMobileNumber(customer.getCustomerMobileNumber());
		if (c2 != null)
			return "Mobile Number already exists!";
		customerService.registerCustomer(customer);
		return "Registered Successfully! Login to continue";
	}
	
	@PostMapping(value="/login",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED)
	public String loginCustomerCheck(@RequestBody Customer customer) {
		return customerService.checkCustomerCredentials(customer.getCustomerEmail(),customer.getCustomerPassword());	
	}
	
	@GetMapping(value="/customer/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Customer getCustomerById(@PathVariable Integer id) {
		return customerService.getCustomerById(id);
		
	}
	
	@PutMapping(value="/customers/{id}",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK)
	public Customer updateCustomer(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer);
	}
	
	@GetMapping(value="/customers",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Customer> getAllCustomers() {
		return customerService.getAllCustomers();
	}
	
	//GET CART BY ID
	@GetMapping(value="/customers/get-cart/{customerId}")
	public List<Integer> getCustomerCartByCustomerId(@PathVariable int customerId){
		return customerService.getCustomerCartById(customerId);
	}
	
	
}
