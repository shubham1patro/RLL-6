package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.AddressService;
import com.example.pojo.Address;

@RestController
@Scope(value="request")
public class AddressController {
	
	@Autowired
	@Qualifier("addressService")
	private AddressService addressService;
	
	
	@GetMapping(value="/addresses",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Address> getAllAddresses() {
		return addressService.getAllAddresses();
	}
	
	@GetMapping(value="/address/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Address getAddressById(@PathVariable("id") Integer id) {
		return addressService.getAddressById(id);
	}
	
	@PutMapping(value="/address/{id}",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Address updateAddress(@RequestBody Address address) {
		return addressService.updateAddress(address);
	}
	

}
