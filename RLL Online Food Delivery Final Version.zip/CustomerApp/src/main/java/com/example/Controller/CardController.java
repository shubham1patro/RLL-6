package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.CardService;
import com.example.pojo.Card;


@RestController
@Scope(value="request")
public class CardController {

	@Autowired
	@Qualifier("cardService")
	private CardService cardService;
	
	
	@GetMapping(value="/cards",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Card> getAllCards() {
		return cardService.getAllCards();
	}
	
	@GetMapping(value="/card/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Card getCardById(@PathVariable("id") Integer id) {
		return cardService.getCardById(id);
	}
	
	@PutMapping(value="/card/{id}",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Card updateCard(@RequestBody Card card) {
		return cardService.updateCard(card);
	}
	
}
