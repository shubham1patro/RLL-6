package com.example.repo;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.pojo.Address;

@Repository(value="addressRepo")
@Scope(value="singleton")
public interface AddressRepo extends JpaRepository<Address, Integer> {

}
