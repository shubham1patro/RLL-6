package com.example.repo;



import java.util.List;


import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.pojo.Address;
import com.example.pojo.Customer;

@Repository(value="customerRepo")
@Scope(value="singleton")
public interface CustomerRepo extends JpaRepository<Customer,Integer> {
	
	public Customer findByCustomerId(int customerId);
	public Customer findByCustomerEmail(String customerEmail);
	public Customer findByCustomerMobileNumber(Long customerMobileNumber);
	public Customer findByCustomerEmailAndCustomerPassword(String customerEmail, String customerPassword);
	//public List<Integer> findCustomerCartByCustomerId(int customerId);

	

	
	
}
