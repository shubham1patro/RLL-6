package com.example.repo;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pojo.Card;

@Repository(value="cardRepo")
@Scope(value="singleton")
public interface CardRepo extends JpaRepository<Card, Integer>{

}
