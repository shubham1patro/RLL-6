package com.example.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Customer{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int customerId;
    private String customerName;
    private String customerEmail;
    private String customerPassword;
    private Long customerMobileNumber;
    
    
    @OneToOne(targetEntity=Card.class,cascade=CascadeType.ALL)
    @JoinTable(name="customer_card",
    joinColumns = {@JoinColumn(name="customerId",referencedColumnName ="customerId")},
    inverseJoinColumns = {@JoinColumn(name="cardId",referencedColumnName ="cardId")})
    private Card customerCard;
    
    @OneToOne(targetEntity=Address.class,cascade=CascadeType.ALL)
    @JoinTable(name="customer_address",
    joinColumns = {@JoinColumn(name="customerId",referencedColumnName ="customerId")},
    inverseJoinColumns = {@JoinColumn(name="addressId",referencedColumnName ="addressId")})
    private Address customerAddress;

    @ElementCollection
    private List<Integer> customerCart;
    
    
    
    
}
