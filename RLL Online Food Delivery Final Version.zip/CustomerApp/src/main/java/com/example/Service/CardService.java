package com.example.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.example.pojo.Card;
import com.example.repo.CardRepo;

@Service(value="cardService")
@Scope(value="singleton")
public class CardService {

	@Autowired
	@Qualifier(value="cardRepo")
	CardRepo cardRepo;
	
	public List<Card> getAllCards(){
		return cardRepo.findAll();
	}
	
	public Card getCardById(Integer id) {
		return cardRepo.findById(id).get();
	}
	
	public Card updateCard(Card card) {
		return cardRepo.save(card);
	}
}
