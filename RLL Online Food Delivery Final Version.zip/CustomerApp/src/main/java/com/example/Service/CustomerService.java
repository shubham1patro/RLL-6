package com.example.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.example.pojo.Address;
import com.example.pojo.Customer;
import com.example.repo.CustomerRepo;

@Service(value="customerService")
@Scope(value="singleton")
public class CustomerService {
	@Autowired
	@Qualifier(value="customerRepo")
	CustomerRepo customerRepo;

	public Customer getCustomerById(int id) {
		return customerRepo.findByCustomerId(id);
	}

	public Customer getCustomerByMobileNumber(Long mobileNumber) {
		return customerRepo.findByCustomerMobileNumber(mobileNumber);
	}

	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
	}

	public String checkCustomerCredentials(String email, String password) {
		Customer customer = customerRepo.findByCustomerEmailAndCustomerPassword(email, password);
		if (customer == null)
			return "invalid";
		else
			return "Login Successful"+customer.getCustomerName();
	}

	public Customer updateCustomer(Customer customer) {
		return customerRepo.save(customer);
	}
	
	public List<Customer> getAllCustomers(){
		return customerRepo.findAll();
	}

	public Customer getCustomerByEmail(String email) {
		return customerRepo.findByCustomerEmail(email);
	}
	
	public List<Integer> getCustomerCartById(int customerId){
		Customer customer = customerRepo.findByCustomerId(customerId);
		List<Integer> list = customer.getCustomerCart();
		return list;
	}
	
	
	
}
