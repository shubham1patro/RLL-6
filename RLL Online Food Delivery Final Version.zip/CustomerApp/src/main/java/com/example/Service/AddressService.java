package com.example.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.example.pojo.Address;
import com.example.repo.AddressRepo;


@Service(value="addressService")
@Scope(value="singleton")
public class AddressService {
	
	@Autowired
	@Qualifier(value="addressRepo")
	AddressRepo addressRepo;
	
	public List<Address> getAllAddresses(){
		return addressRepo.findAll();
	}
	
	public Address getAddressById(Integer id) {
		return addressRepo.findById(id).get();
	}
	
	public Address updateAddress(Address address) {
		return addressRepo.save(address);
	}
	

}
