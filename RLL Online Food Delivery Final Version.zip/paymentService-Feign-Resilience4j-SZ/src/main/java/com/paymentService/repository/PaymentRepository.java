package com.paymentService.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.paymentService.domain.Invoice;

@Repository(value = "paymentRepository")
@Scope(value = "singleton")
public interface PaymentRepository extends JpaRepository<Invoice, Integer>{

}
