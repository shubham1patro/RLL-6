package com.paymentService.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.paymentService.domain.Orders;


@FeignClient("order-service")
public interface OrderServiceProxy {

	@GetMapping(value="/order/{orderId}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Orders getOrderById(@PathVariable int orderId);
}
