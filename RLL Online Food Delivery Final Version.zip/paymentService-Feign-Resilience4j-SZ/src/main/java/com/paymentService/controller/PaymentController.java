package com.paymentService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.paymentService.domain.Customer;
import com.paymentService.domain.Invoice;
import com.paymentService.service.IPaymentService;

@RestController
@Scope(value = "request")
public class PaymentController {

	@Autowired
	@Qualifier("paymentService")
	private IPaymentService paymentService;
	
	@PutMapping(value = "/payment/{orderId}")
	public String debitFromCard(@PathVariable int orderId) {
		return "PAYMENT SUCCESSFUL /n"+ paymentService.debitBalance(orderId);
	}
	
	@PostMapping(value = "/invoice/{orderId}")
	public Invoice generateInvoice(@PathVariable int orderId) {
		return paymentService.generateInvoice(orderId);
	}
}
