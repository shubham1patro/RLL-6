package com.paymentService.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.paymentService.domain.Address;
import com.paymentService.domain.Card;
import com.paymentService.domain.Customer;
import com.paymentService.domain.Invoice;
import com.paymentService.domain.Orders;
import com.paymentService.proxy.CustomerServiceProxy;
import com.paymentService.proxy.OrderServiceProxy;
import com.paymentService.repository.PaymentRepository;

@Service(value = "paymentService")
@Scope(value = "singleton")
public class PaymentService implements IPaymentService{
	
	@Autowired
	private CustomerServiceProxy customerServiceProxy;
	@Autowired
	private OrderServiceProxy orderServiceProxy;
	@Autowired
	private PaymentRepository paymentRepository;

	@Override
	public Customer debitBalance(int orderId) {
	Orders order = orderServiceProxy.getOrderById(orderId);
	long orderAmount = (long) order.getOrderTotal();
	int customerId = order.getOrderCustomer();
	Customer customer = customerServiceProxy.getCustomerById(customerId);
	Card card = customer.getCustomerCard();
	long cardBalance = card.getCardBalance();
	long finalBalance = cardBalance - orderAmount;	
	card.setCardBalance(finalBalance);				//SETTING CARD BALANCE AFTER DEBIT
	customer.setCustomerCard(card);  
	return customerServiceProxy.updateCustomer(customer);
	}

	@Override
	public Invoice generateInvoice(int orderId) {
		Orders order = orderServiceProxy.getOrderById(orderId);  //GETTING ORDER BY ID
		double orderAmount = order.getOrderTotal();				//GET ORDER AMOUNT
		List<Integer> orderItems = order.getOrderItems();		//GET ORDER ITEMS
		int customerId = order.getOrderCustomer();				//GET ORDER CUSTOMER ID
		
		Customer customer = customerServiceProxy.getCustomerById(customerId); //GET CUSTOMER
																
		Invoice invoice = new Invoice();						//NEW INVOICE
		invoice.setInvoiceDate(LocalDate.now());				//SET INVOICE DATE
		invoice.setInvoiceItems(orderItems);					//SET INVOICE ITEMS
		invoice.setInvoiceDeliveryAddress(customer.getCustomerAddress().toString());//SET INVOICE ADDRESS				//SET INVOICE DELIVERY ADDRESS
		invoice.setInvoiceAmount(orderAmount);					//SET INVOICE AMOUNT
		
		return paymentRepository.save(invoice);					//SAVE INVOICE
	}

	
}
