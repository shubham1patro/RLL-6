package com.paymentService.service;

import com.paymentService.domain.Customer;
import com.paymentService.domain.Invoice;

public interface IPaymentService {
	
	public Customer debitBalance(int orderId);
	public Invoice generateInvoice(int orderId);
	

}
