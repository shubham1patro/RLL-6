package com.adminApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.adminApp.domain.Admin;
import com.adminApp.service.IAdminService;

@RestController
@Scope("request")
public class AdminController {
	@Autowired
	private IAdminService adminService;
	
	@PostMapping(value = "/create", produces = {MediaType.APPLICATION_JSON_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Admin registerAdmin(@RequestBody Admin admin) {
		System.out.println("admin object is : " +admin.toString());
		return adminService.addAdmin(admin);
	}
	
	@GetMapping(value = "/admin/{adminId}")
	public Admin getAdminById(@PathVariable int adminId) {
		return adminService.getAdminById(adminId);
	}
	
	@GetMapping(value = "/admin")
	public List<Admin> getAllAdmin(){
		return adminService.getAllAdmin();
	}
	
	@PutMapping(value = "/update-admin")
	public Admin updateAdmin(@RequestBody Admin admin) {
		return adminService.updateAdmin(admin);
	}
	
	@DeleteMapping(value = "/admin/{id}")
	public void deleteAdmin(@PathVariable int id) {
		adminService.deleteAdmin(id);
	}

}
