package com.adminApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.adminApp.domain.Admin;
import com.adminApp.repository.AdminRepository;

@Service(value="adminService")
@Scope(value="singleton")
public class AdminService implements IAdminService{

	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public Admin addAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public Admin getAdminById(int adminId) {
		return adminRepository.findById(adminId).get();
	}

	@Override
	public List<Admin> getAllAdmin() {
		return adminRepository.findAll();
	}

	@Override
	public Admin updateAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public void deleteAdmin(int id) {
		adminRepository.deleteById(id);
		
	}

}
