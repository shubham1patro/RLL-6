package com.adminApp.service;

import java.util.List;

import com.adminApp.domain.Admin;

public interface IAdminService {
	
	public Admin addAdmin(Admin admin);
	public Admin getAdminById(int adminId);
	public List<Admin> getAllAdmin();
	public Admin updateAdmin(Admin admin);
	public void deleteAdmin(int id);
}
