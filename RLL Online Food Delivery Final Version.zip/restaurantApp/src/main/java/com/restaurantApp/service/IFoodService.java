package com.restaurantApp.service;

import java.util.List;


import com.restaurantApp.domain.Food;

public interface IFoodService {
	
	public Food addFood(Food food);
	public Food updateFood(Food food);
	public List<Food> getAllFoods();
	public Food getFoodById(Integer id);
	public void deleteById(Integer id);
	public double getFoodPriceByFoodId(Integer foodId);

}
