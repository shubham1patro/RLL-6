package com.restaurantApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.restaurantApp.domain.Food;
import com.restaurantApp.repository.FoodRepository;

@Service(value = "foodService")
@Scope(value = "singleton")
public class FoodService implements IFoodService{
	
	@Autowired
	@Qualifier(value = "foodRepository")
	private FoodRepository foodRepository;

	@Override
	public Food addFood(Food food) {	
		return foodRepository.save(food);
	}

	@Override
	public Food updateFood(Food food) {
		return foodRepository.save(food);
	}

	@Override
	public List<Food> getAllFoods() {
		return foodRepository.findAll();
	}

	@Override
	public Food getFoodById(Integer id) {
		return foodRepository.findById(id).get();
	}

	@Override
	public void deleteById(Integer id) {
		foodRepository.deleteById(id);;
		
	}

	@Override
	public double getFoodPriceByFoodId(Integer foodId) {
		Food food = foodRepository.findById(foodId).get();
		return food.getFoodPrice();
	}

}
