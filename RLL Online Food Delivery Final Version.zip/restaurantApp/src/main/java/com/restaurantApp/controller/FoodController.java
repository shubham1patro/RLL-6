package com.restaurantApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.restaurantApp.domain.Food;
import com.restaurantApp.service.IFoodService;

@RestController
@Scope(value = "request")
public class FoodController {
	
	@Autowired
	@Qualifier("foodService")
	private IFoodService foodService;
	
	@PostMapping(value = "/foods", produces = {MediaType.APPLICATION_JSON_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus (code = HttpStatus.CREATED)
	public Food addFood(@RequestBody Food food) {
		return foodService.addFood(food);
	}
	
	@PutMapping(value = "/foods", produces = {MediaType.APPLICATION_JSON_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus (code = HttpStatus.OK)
	public Food updateFood(@RequestBody Food food) {
		return foodService.updateFood(food);
	}
	
	@GetMapping(value ="/foods/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Food getFoodById(@PathVariable int id) {
		return foodService.getFoodById(id);
	}
	
	@GetMapping(value ="/foods", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Food> getAllFoods() {
		return foodService.getAllFoods();
	}
	
	@DeleteMapping(value = "/foods/{id}")
	@ResponseStatus (code = HttpStatus.NO_CONTENT)
	public void deleteFoodById(@PathVariable int id ) {
		foodService.deleteById(id);
	}
	
	@GetMapping(value = "/food/price/{foodId}")
	public double getFoodPriceByFoodId(@PathVariable int foodId) {
		return foodService.getFoodPriceByFoodId(foodId);
	}

}
