package com.restaurantApp.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.restaurantApp.domain.Food;

@Repository(value = "foodRepository")
@Scope(value = "singleton")
public interface FoodRepository extends JpaRepository<Food, Integer>{
	
	public double  findFoodPriceByFoodId(int foodId);

}
