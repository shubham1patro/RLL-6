package com.orderService.service;

import java.util.List;

import com.orderService.domain.Food;
import com.orderService.domain.Orders;

public interface IOrderService {

	
	public Orders getOrderById(Integer orderId);
	public List<Orders> getAllOrders();
	public Orders placeOrder(int customerId);
	public List<Orders> getOrderByCustomerId(int customerId);

}
