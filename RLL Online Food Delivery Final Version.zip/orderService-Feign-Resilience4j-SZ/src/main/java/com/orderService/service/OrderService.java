package com.orderService.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.orderService.domain.Customer;
import com.orderService.domain.Orders;
import com.orderService.proxy.CustomerServiceProxy;
import com.orderService.proxy.RestaurantServiceProxy;
import com.orderService.repository.OrderRepository;

@Service(value = "orderService")
@Scope(value = "singleton")
public class OrderService implements IOrderService{
	
	@Autowired
	@Qualifier(value = "orderRepository")
	private OrderRepository orderRepository;
	
	@Autowired
	private RestaurantServiceProxy restaurantServiceProxy;
	@Autowired	
	private CustomerServiceProxy customerServiceProxy;

	@Override
	public Orders getOrderById(Integer orderId) {
		return orderRepository.findByOrderId(orderId);
	}

	@Override
	public List<Orders> getAllOrders() {
		return orderRepository.findAll();
	}

	@Override
	public Orders placeOrder(int customerId) {
		List<Integer> list = customerServiceProxy.getCustomerCartByCustomerId(customerId);
		Customer customer = customerServiceProxy.getCustomerById(customerId);
		customer.setCustomerCart(null);			//EMPTYING CUSTOMER SHOPPING CART
		Orders order = new Orders();
		order.setOrderDate(LocalDate.now());		//SETTING ORDER
		order.setOrderItems(list);
		double total = 0;
		for(int foodId : list) {
			total = total + restaurantServiceProxy.getFoodPriceByFoodId(foodId);}
		order.setOrderTotal(total);
		order.setOrderCustomer(customerId);
		total = 0;
		return orderRepository.save(order) ;
	}

	@Override
	public List<Orders> getOrderByCustomerId(int customerId) {
		return orderRepository.findByOrderCustomer(customerId);
	}
	

}
