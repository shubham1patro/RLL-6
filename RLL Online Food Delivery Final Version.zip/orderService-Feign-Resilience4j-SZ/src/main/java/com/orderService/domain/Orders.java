package com.orderService.domain;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;
	private LocalDate orderDate;
	private double orderTotal;
	
//	@ManyToMany(cascade=CascadeType.ALL)
//    @JoinTable(name="order_food",
//    joinColumns = {@JoinColumn(name="orderId",referencedColumnName ="orderId")},
//    inverseJoinColumns = {@JoinColumn(name="foodId",referencedColumnName ="foodId")})  
	@ElementCollection
	private List<Integer> orderItems;
	
//	@OneToOne(cascade=CascadeType.ALL)
//	@JoinTable(name="customer_order",
//	joinColumns = {@JoinColumn(name="orderId",referencedColumnName ="orderId")},
//	inverseJoinColumns = {@JoinColumn(name="customerId",referencedColumnName ="customerId")})

	private int orderCustomer;
	
}
