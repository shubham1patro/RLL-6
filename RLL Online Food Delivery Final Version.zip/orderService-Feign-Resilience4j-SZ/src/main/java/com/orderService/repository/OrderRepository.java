package com.orderService.repository;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.orderService.domain.Orders;

@Repository(value = "orderRepository")
@Scope(value = "singleton")
public interface OrderRepository extends JpaRepository<Orders, Integer>{

	public Orders findByOrderId(Integer orderId);
	public List<Orders> findByOrderCustomer(int orderCustomer);
}
