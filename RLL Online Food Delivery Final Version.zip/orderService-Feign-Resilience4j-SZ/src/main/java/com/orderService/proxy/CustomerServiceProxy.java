package com.orderService.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.orderService.domain.Customer;


@FeignClient("customer-service")
public interface CustomerServiceProxy {
	
	@GetMapping(value="/customer/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Customer getCustomerById(@PathVariable Integer id);
	
	@PutMapping(value="/customers",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK)
	public Customer updateCustomer(@RequestBody Customer customer);

	@GetMapping(value="/customers/get-cart/{customerId}")
	public List<Integer> getCustomerCartByCustomerId(@PathVariable int customerId);
}
