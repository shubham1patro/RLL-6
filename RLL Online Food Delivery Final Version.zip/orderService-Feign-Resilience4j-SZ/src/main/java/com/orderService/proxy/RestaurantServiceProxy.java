package com.orderService.proxy;

import java.util.ArrayList;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.orderService.domain.Food;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("restaurant-service")
public interface RestaurantServiceProxy {
	
	@Retry(name="restaurant-service")
	@CircuitBreaker(name="restaurant-service",fallbackMethod = "getFallbackFoodById")
	@GetMapping(value ="/foods/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Food getFoodById(@PathVariable int id);
	
	@Retry(name="restaurant-service")
	@CircuitBreaker(name="restaurant-service",fallbackMethod = "getFallbackFoodPriceByFoodId")
	@GetMapping(value = "/food/price/{foodId}")
	public double getFoodPriceByFoodId(@PathVariable int foodId);
	
	@Retry(name="restaurant-service")
	@CircuitBreaker(name="restaurant-service",fallbackMethod = "getFallBackAllFood")
	@GetMapping(value ="/foods", produces = {MediaType.APPLICATION_JSON_VALUE})
	public  List<Food> getAllFoods();
	
    public default Food getFallbackFoodById(int id, Throwable cause) {
 		Food fallbackFood = new Food();
        fallbackFood.setFoodId(id);
        fallbackFood.setFoodName("Juice");
        fallbackFood.setFoodDescription("Fallback Food Description");
        fallbackFood.setFoodPrice(485.6);
        fallbackFood.setFoodAvailability(true);
        return fallbackFood;
    }
 	
     public default double getFallbackFoodPriceByFoodId(int foodId,Throwable cause) {
         return 784.50; 
     }
     
     public default List<Food> getFallBackAllFood(Throwable cause) {
    	 Food fallbackFood = new Food(1, "Water", "Desc", 20.00, true);
    	 Food fallbackFood1 = new Food(2, "Pepsi", "Desc", 40.00, true);
    	 Food fallbackFood2 = new Food(3, "Coke", "Desc", 40.00, true);
    	 
    	 List<Food> list = new ArrayList<>();
    	 list.add(fallbackFood);
    	 list.add(fallbackFood1);
    	 list.add(fallbackFood2);
    	 
    	 return list;
     }


}
