package com.orderService.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.orderService.domain.Customer;
import com.orderService.domain.Food;
import com.orderService.domain.Orders;
import com.orderService.proxy.CustomerServiceProxy;
import com.orderService.proxy.RestaurantServiceProxy;
import com.orderService.service.IOrderService;

@RestController
@Scope(value = "request")
public class OrderController {

	@Autowired
	private CustomerServiceProxy customerServiceProxy;
	
	@Autowired
	private RestaurantServiceProxy restaurantServiceProxy;
	
	@Autowired
	@Qualifier("orderService")
	private IOrderService orderService;
	
	private Logger log = LoggerFactory.getLogger(OrderController.class);
	
	
	//ADD FOOD TO CUSTOMER CART
	@PutMapping(value="/add-to-cart/{customerId}/{foodId}",produces= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK)
	public Customer addToCart(@PathVariable int customerId, @PathVariable int foodId) {
		Customer customer = customerServiceProxy.getCustomerById(customerId);
		customer.getCustomerCart().add(foodId);
		return customerServiceProxy.updateCustomer(customer);	
	}
	
	//GENERATE ORDER 
	@PostMapping(value="/place-order/{customerId}", produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED)
	@Transactional
	public Orders placeOrder(@PathVariable int customerId) {	
		return orderService.placeOrder(customerId);	
	}
	
	//GET ORDER BY ORDER ID
	@GetMapping(value="/order/{orderId}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Orders getOrderById(@PathVariable int orderId) {
		System.out.println("*********** ID IS_____"+orderId);
		return orderService.getOrderById(orderId);
	}
	
	//GET ALL ORDER BY CUSTOMER ID
	@GetMapping(value="/order-customer/{customerId}")
	public List<Orders> getOrderByCustomerId(@PathVariable int customerId) {
		Orders order = new Orders();
		return orderService.getOrderByCustomerId(customerId);
	}
	
	@GetMapping(value ="/foods/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Food getFoodById(@PathVariable int id) {
		return restaurantServiceProxy.getFoodById(id);
	}
	
	@GetMapping(value = "/food/price/{foodId}")
	public double getFoodPriceByFoodId(@PathVariable int foodId) {
		return restaurantServiceProxy.getFoodPriceByFoodId(foodId);

	}
	@GetMapping(value ="/foods", produces = {MediaType.APPLICATION_JSON_VALUE})
	public  List<Food> getAllFoods(){
		return restaurantServiceProxy.getAllFoods();
	}
}
