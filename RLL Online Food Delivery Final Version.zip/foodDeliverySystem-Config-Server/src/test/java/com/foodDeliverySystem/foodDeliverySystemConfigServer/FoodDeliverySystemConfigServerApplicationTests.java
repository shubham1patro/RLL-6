package com.foodDeliverySystem.foodDeliverySystemConfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliverySystemConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
