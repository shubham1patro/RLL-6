package com.foodDeliverySystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliverySystemEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
